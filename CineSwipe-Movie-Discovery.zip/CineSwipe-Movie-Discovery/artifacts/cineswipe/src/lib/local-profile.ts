export type SavedState = {
  liked: string[];
  passed: string[];
  watched: string[];
};

const GUEST_LIBRARY_KEY = 'cineswipe-library-v1';
const USER_LIBRARY_PREFIX = 'cineswipe-library-user:';
const SESSION_KEY = 'cineswipe-session-v1';

export function normalizeUsername(value: string): string | null {
  const username = value.trim().replace(/^@+/, '').toLowerCase();
  return /^[\p{L}\p{M}\p{N}_]{3,20}$/u.test(username) ? username : null;
}

export function readActiveUsername(): string | null {
  try {
    const storedUsername = localStorage.getItem(SESSION_KEY);
    return storedUsername ? normalizeUsername(storedUsername) : null;
  } catch {
    return null;
  }
}

export function setActiveUsername(username: string | null) {
  try {
    if (username) {
      localStorage.setItem(SESSION_KEY, username);
    } else {
      localStorage.removeItem(SESSION_KEY);
    }
  } catch {
    // Keep the active session usable even if browser storage is unavailable.
  }
}

export function readSavedForUser(username: string | null): SavedState {
  const key = username ? `${USER_LIBRARY_PREFIX}${username}` : GUEST_LIBRARY_KEY;
  try {
    const parsed = JSON.parse(localStorage.getItem(key) || '{}') as Partial<SavedState>;
    const stringIds = (value: unknown) =>
      Array.isArray(value) ? value.filter((id): id is string => typeof id === 'string') : [];

    return {
      liked: stringIds(parsed.liked),
      passed: stringIds(parsed.passed),
      watched: stringIds(parsed.watched),
    };
  } catch {
    return { liked: [], passed: [], watched: [] };
  }
}

export function saveForUser(username: string | null, saved: SavedState) {
  const key = username ? `${USER_LIBRARY_PREFIX}${username}` : GUEST_LIBRARY_KEY;
  try {
    localStorage.setItem(key, JSON.stringify(saved));
  } catch {
    // Swiping remains available in memory if browser storage is full or blocked.
  }
}
