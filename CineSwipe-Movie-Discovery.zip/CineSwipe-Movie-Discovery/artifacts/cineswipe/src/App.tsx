import { useEffect, useMemo, useRef, useState, type PointerEvent as ReactPointerEvent } from 'react';
import { Link, Route, Switch, useLocation } from 'wouter';
import {
  Bookmark, Check, ChevronRight, Clapperboard, Clock3, Compass, Film, UserRound,
  Filter, Heart, RotateCcw, SlidersHorizontal, Star, ThumbsUp, X, Users, Crown,
  MessageCircle, LockKeyhole, ChevronDown, UserPlus, UserCheck, Share2,
} from 'lucide-react';
import ProfileModal from '@/components/ProfileModal';
import MovieDetailSheet, { type Movie } from '@/components/MovieDetailSheet';
import StoryOverlay from '@/components/StoryOverlay';
import ProfilePage from '@/components/ProfilePage';
import {
  readActiveUsername,
  readSavedForUser,
  saveForUser,
  setActiveUsername,
  type SavedState,
} from '@/lib/local-profile';

const catalog: Movie[] = [
  {
    id: 'interstellar', title: 'Interstellar', year: 2014, rating: 8.7, runtime: 169,
    genres: ['Bilim Kurgu', 'Dram'], providers: ['Max', 'Prime Video'],
    posterUrl: 'https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg',
    synopsis: 'İnsanlığın geleceği için yıldızların ötesine uzanan, zaman ve aile üzerine unutulmaz bir yolculuk.',
  },
  {
    id: 'inception', title: 'Inception', year: 2010, rating: 8.8, runtime: 148,
    genres: ['Bilim Kurgu', 'Aksiyon'], providers: ['Max', 'Netflix'],
    posterUrl: 'https://image.tmdb.org/t/p/w500/oYuLEt3zVCKq57qu2F8dT7NIa6f.jpg',
    synopsis: 'Rüyaların içinde fikir çalan bir hırsız, bu kez imkânsız görünen bir fikri zihne yerleştirmekle görevlendirilir.',
  },
  {
    id: 'dark-knight', title: 'The Dark Knight', year: 2008, rating: 9.0, runtime: 152,
    genres: ['Aksiyon', 'Suç'], providers: ['Max'],
    posterUrl: 'https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg',
    synopsis: 'Gotham’ın koruyucusu, şehri kaosa sürükleyen Joker karşısında sınırlarını yeniden keşfeder.',
  },
  {
    id: 'whiplash', title: 'Whiplash', year: 2014, rating: 8.5, runtime: 107,
    genres: ['Dram', 'Müzik'], providers: ['Netflix', 'MUBI'],
    posterUrl: 'https://image.tmdb.org/t/p/w500/7fn624j5lj3xTme2SgiLCeuedmO.jpg',
    synopsis: 'Genç bir davulcu, mükemmelliğin bedelini acımasız bir eğitmenin gölgesinde öğrenir.',
  },
  {
    id: 'dune', title: 'Dune', year: 2021, rating: 8.0, runtime: 155,
    genres: ['Bilim Kurgu', 'Macera'], providers: ['Max', 'Prime Video'],
    posterUrl: 'https://image.tmdb.org/t/p/w500/d5NXSklXo0qyIYkgV94XAgMIckC.jpg',
    synopsis: 'Çöl gezegeninin kaderi ve ailesinin geleceği için Paul Atreides bilinmeyene doğru yola çıkar.',
  },
  {
    id: 'get-out', title: 'Get Out', year: 2017, rating: 7.8, runtime: 104,
    genres: ['Korku', 'Gerilim'], providers: ['Netflix', 'Prime Video'],
    posterUrl: 'https://image.tmdb.org/t/p/w500/tFXcEccSQMf3lfhfXKSU9iRBpa3.jpg',
    synopsis: 'Bir hafta sonu ziyareti, Chris’in hiç beklemediği karanlık bir gerçeğe dönüşür.',
  },
  {
    id: 'lord-of-the-rings', title: 'The Lord of the Rings', year: 2001, rating: 8.8, runtime: 178,
    genres: ['Fantastik', 'Macera'], providers: ['Max', 'Prime Video'],
    posterUrl: 'https://image.tmdb.org/t/p/w500/6oom5QYQ2yQTMJIbnvbkBL9cHo6.jpg',
    synopsis: 'Genç bir hobbit, dünyayı karanlıktan koruyabilecek yüzüğü yok etmek için yola çıkar.',
  },
  {
    id: 'spirited-away', title: 'Spirited Away', year: 2001, rating: 8.6, runtime: 125,
    genres: ['Animasyon', 'Fantastik', 'Macera'], providers: ['Netflix', 'Prime Video'],
    posterUrl: 'https://image.tmdb.org/t/p/w500/39wmItIWsg5sZMyRUHLkWBcuVCM.jpg',
    synopsis: 'Gizemli bir ruhlar dünyasında Chihiro, ailesini kurtarmak için cesaretini bulmalıdır.',
  },
  {
    id: 'grand-budapest', title: 'The Grand Budapest Hotel', year: 2014, rating: 8.1, runtime: 99,
    genres: ['Komedi', 'Dram'], providers: ['Netflix', 'Prime Video'],
    posterUrl: 'https://image.tmdb.org/t/p/w500/eWdyYQreja6JGCzqHWXpWHDrrPo.jpg',
    synopsis: 'Bir otel görevlisi ve genç çırağı, Avrupa’da geçen tuhaf bir miras macerasına atılır.',
  },
  {
    id: 'free-solo', title: 'Free Solo', year: 2018, rating: 8.1, runtime: 100,
    genres: ['Belgesel', 'Macera'], providers: ['Prime Video'],
    posterUrl: 'https://image.tmdb.org/t/p/w500/v4QfYZMACODlWul9doN9RxE99ag.jpg',
    synopsis: 'Alex Honnold, Yosemite’deki El Capitan’a ip kullanmadan tırmanmaya hazırlanır.',
  },
  {
    id: 'truman-show', title: 'The Truman Show', year: 1998, rating: 8.2, runtime: 103,
    genres: ['Komedi', 'Dram'], providers: ['Prime Video'],
    posterUrl: 'https://image.tmdb.org/t/p/w500/vuza0WqY239yBXOadKlGwJsZJFE.jpg',
    synopsis: 'Truman Burbank’in kusursuz görünen hayatı, dünyanın gözleri önünde kurulmuş dev bir televizyon setidir.',
  },
  {
    id: 'groundhog-day', title: 'Groundhog Day', year: 1993, rating: 8.0, runtime: 101,
    genres: ['Komedi', 'Romantik'], providers: ['Netflix'],
    posterUrl: 'https://image.tmdb.org/t/p/w500/gCgt1WARPZaXnq523ySQEUKinCs.jpg',
    synopsis: 'Kibirli bir hava durumu sunucusu, aynı günü tekrar tekrar yaşarken hayatına yeni bir anlam arar.',
  },
];

const metadata: Record<string, Pick<Movie, 'originalTitle' | 'country' | 'director' | 'cast' | 'trailerUrl' | 'backdropUrl'>> = {
  interstellar: { originalTitle: 'Interstellar', country: 'ABD, Birleşik Krallık', director: 'Christopher Nolan', cast: ['Matthew McConaughey', 'Anne Hathaway', 'Jessica Chastain', 'Michael Caine'], backdropUrl: 'https://image.tmdb.org/t/p/w780/rAiYTfKGqDCRIIqo664sY9XZIvQ.jpg', trailerUrl: 'https://www.youtube.com/results?search_query=Interstellar+official+trailer' },
  inception: { originalTitle: 'Inception', country: 'ABD, Birleşik Krallık', director: 'Christopher Nolan', cast: ['Leonardo DiCaprio', 'Joseph Gordon-Levitt', 'Elliot Page', 'Michael Caine'], backdropUrl: 'https://image.tmdb.org/t/p/w780/s3TBrRGB1iav7gFOCNx3H31MoES.jpg', trailerUrl: 'https://www.youtube.com/results?search_query=Inception+official+trailer' },
  'dark-knight': { originalTitle: 'The Dark Knight', country: 'ABD, Birleşik Krallık', director: 'Christopher Nolan', cast: ['Christian Bale', 'Heath Ledger', 'Aaron Eckhart', 'Michael Caine'], backdropUrl: 'https://image.tmdb.org/t/p/w780/hkBaDkMWbLaf8B1lsWsKX7Ew3Xq.jpg', trailerUrl: 'https://www.youtube.com/results?search_query=The+Dark+Knight+official+trailer' },
  whiplash: { originalTitle: 'Whiplash', country: 'ABD', director: 'Damien Chazelle', cast: ['Miles Teller', 'J. K. Simmons', 'Melissa Benoist'] },
  dune: { originalTitle: 'Dune', country: 'ABD, Kanada', director: 'Denis Villeneuve', cast: ['Timothée Chalamet', 'Rebecca Ferguson', 'Oscar Isaac'], backdropUrl: 'https://image.tmdb.org/t/p/w780/jYEW5xZkZk2WTrdbMGAPFuBqbDc.jpg' },
  'get-out': { originalTitle: 'Get Out', country: 'ABD', director: 'Jordan Peele', cast: ['Daniel Kaluuya', 'Allison Williams', 'Bradley Whitford'] },
  'lord-of-the-rings': { originalTitle: 'The Lord of the Rings: The Fellowship of the Ring', country: 'Yeni Zelanda, ABD', director: 'Peter Jackson', cast: ['Elijah Wood', 'Ian McKellen', 'Viggo Mortensen'] },
  'spirited-away': { originalTitle: '千と千尋の神隠し', country: 'Japonya', director: 'Hayao Miyazaki', cast: ['Rumi Hiiragi', 'Miyu Irino', 'Mari Natsuki'] },
  'grand-budapest': { originalTitle: 'The Grand Budapest Hotel', country: 'ABD, Almanya', director: 'Wes Anderson', cast: ['Ralph Fiennes', 'Tony Revolori', 'Saoirse Ronan'] },
  'free-solo': { originalTitle: 'Free Solo', country: 'ABD', director: 'Elizabeth Chai Vasarhelyi, Jimmy Chin', cast: ['Alex Honnold', 'Tommy Caldwell'] },
  'truman-show': { originalTitle: 'The Truman Show', country: 'ABD', director: 'Peter Weir', cast: ['Jim Carrey', 'Laura Linney', 'Ed Harris'] },
  'groundhog-day': { originalTitle: 'Groundhog Day', country: 'ABD', director: 'Harold Ramis', cast: ['Bill Murray', 'Andie MacDowell', 'Chris Elliott'] },
};
const movies: Movie[] = catalog.map(movie => ({ ...movie, ...(metadata[movie.id] || {}) }));

type DiscoveryFilters = {
  genres: string[];
  minYear: number;
  maxYear: number;
  minRating: number;
};

const defaultDiscoveryFilters: DiscoveryFilters = {
  genres: [],
  minYear: 1970,
  maxYear: 2024,
  minRating: 7,
};

const discoveryGenres = [
  'Bilim Kurgu', 'Dram', 'Aksiyon', 'Romantik',
  'Gerilim', 'Suç', 'Müzik', 'Macera', 'Korku',
  'Fantastik', 'Animasyon', 'Komedi', 'Belgesel',
];
const discoveryYearOptions = [1970, 1980, 1990, 2000, 2005, 2010, 2015, 2020, 2024];

function matchesDiscoveryFilters(movie: Movie, filters: DiscoveryFilters) {
  const matchesGenre =
    filters.genres.length === 0 ||
    movie.genres.some((genre) => filters.genres.includes(genre));

  return (
    matchesGenre &&
    movie.year >= filters.minYear &&
    movie.year <= filters.maxYear &&
    movie.rating >= filters.minRating
  );
}

function Header({ username, onOpenProfile }: { username: string | null; onOpenProfile: () => void }) {
  return (
    <header className="topbar" data-testid="app-header">
      <Link href="/" className="brand" data-testid="link-brand">
        <span className="brand-mark"><Clapperboard size={20} strokeWidth={2.5} /></span>
        <span>CineSwipe</span>
      </Link>
      <div className="header-actions">
        {!username && (
          <div className="room-pill" data-testid="room-code">
            <span className="room-dot" /> <span className="room-label">Oda:</span> <span style={{ color: '#f8fafc' }}>#84920</span>
          </div>
        )}
        <button
          className={`profile-trigger ${username ? 'has-username' : ''}`}
          type="button"
          onClick={onOpenProfile}
          aria-label={username ? `Profil: @${username}` : 'Giriş Yap / Kaydol'}
          title={username ? `@${username}` : 'Giriş Yap / Kaydol'}
          data-testid="button-open-profile"
        >
          <UserRound size={17} />
          {username && <span className="profile-username" data-testid="text-active-username">@{username}</span>}
        </button>
      </div>
    </header>
  );
}

function BottomNav() {
  const [location] = useLocation();
  const items = [
    { href: '/', label: 'Keşfet', icon: Compass },
    { href: '/curated', label: 'Küratör Listeleri', icon: Film },
    { href: '/library', label: 'Kütüphanem', icon: Bookmark },
    { href: '/matches', label: 'Eşleşmeler', icon: Users },
  ];
  return (
    <nav className="bottom-nav" aria-label="Ana gezinme" data-testid="bottom-navigation">
      {items.map(({ href, label, icon: Icon }) => (
        <Link key={href} href={href} className={`nav-link ${location === href ? 'active' : ''}`} data-testid={`nav-${href === '/' ? 'discover' : href.slice(1)}`}>
          <span className="nav-icon"><Icon size={19} strokeWidth={2.2} /></span>
          <span>{label}</span>
        </Link>
      ))}
    </nav>
  );
}

function Discovery({ saved, setSaved, queueIds, queueTitle, onExitQueue, onMovieOpen, onStory }: {
  saved: SavedState; setSaved: (value: SavedState) => void; queueIds: string[] | null;
  queueTitle: string | null; onExitQueue: () => void;
  onMovieOpen: (movie: Movie) => void; onStory: (movie: Movie) => void;
}) {
  const [gestureX, setGestureX] = useState(0);
  const pointerStart = useRef<number | null>(null);
  const dragged = useRef(false);
  const [lastAction, setLastAction] = useState<{ id: string; type: 'like' | 'pass' } | null>(null);
  const [filtersOpen, setFiltersOpen] = useState(false);
  const [draftFilters, setDraftFilters] = useState<DiscoveryFilters>(() => ({
    ...defaultDiscoveryFilters,
    genres: [],
  }));
  const [appliedFilters, setAppliedFilters] = useState<DiscoveryFilters>(() => ({
    ...defaultDiscoveryFilters,
    genres: [],
  }));
  const [matchFeedback, setMatchFeedback] = useState<{ count: number } | null>(null);
  const matchedMovies = useMemo(
    () => movies.filter(movie =>
      (!queueIds || queueIds.includes(movie.id)) && matchesDiscoveryFilters(movie, appliedFilters),
    ),
    [appliedFilters, queueIds],
  );
  const queue = useMemo(
    () => matchedMovies.filter(movie => !saved.liked.includes(movie.id) && !saved.passed.includes(movie.id)),
    [matchedMovies, saved.liked, saved.passed],
  );
  const current = queue[0];

  useEffect(() => {
    if (matchFeedback === null) return;
    const timeout = window.setTimeout(() => setMatchFeedback(null), 3600);
    return () => window.clearTimeout(timeout);
  }, [matchFeedback]);

  const applyFilters = () => {
    const filters = { ...draftFilters, genres: [...draftFilters.genres] };
    setAppliedFilters(filters);
    setMatchFeedback({
      count: movies.filter((movie) =>
        (!queueIds || queueIds.includes(movie.id)) && matchesDiscoveryFilters(movie, filters),
      ).length,
    });
    setFiltersOpen(false);
  };

  const resetFilters = () => {
    const filters = { ...defaultDiscoveryFilters, genres: [] };
    setDraftFilters(filters);
    setAppliedFilters(filters);
    setMatchFeedback({
      count: movies.filter((movie) =>
        (!queueIds || queueIds.includes(movie.id)) && matchesDiscoveryFilters(movie, filters),
      ).length,
    });
  };

  const decide = (type: 'like' | 'pass') => {
    if (!current) return;
    setSaved({
      ...saved,
      liked: type === 'like' ? [...saved.liked, current.id] : saved.liked,
      passed: type === 'pass' ? [...saved.passed, current.id] : saved.passed,
    });
    setLastAction({ id: current.id, type });
    setGestureX(0);
  };

  const undo = () => {
    if (!lastAction) return;
    setSaved({
      ...saved,
      liked: saved.liked.filter(id => !(lastAction.type === 'like' && id === lastAction.id)),
      passed: saved.passed.filter(id => !(lastAction.type === 'pass' && id === lastAction.id)),
    });
    setLastAction(null);
  };

  const onPointerDown = (event: ReactPointerEvent<HTMLElement>) => {
    if ((event.target as HTMLElement).closest('button,a')) return;
    pointerStart.current = event.clientX;
    dragged.current = false;
    event.currentTarget.setPointerCapture(event.pointerId);
  };
  const onPointerMove = (event: ReactPointerEvent<HTMLElement>) => {
    if (pointerStart.current !== null) {
      const delta = event.clientX - pointerStart.current;
      if (Math.abs(delta) > 8) dragged.current = true;
      setGestureX(delta);
    }
  };
  const onPointerUp = () => {
    if (pointerStart.current === null) return;
    if (gestureX > 85) decide('like');
    else if (gestureX < -85) decide('pass');
    pointerStart.current = null;
    setGestureX(0);
  };

  return (
    <main className="page" data-testid="page-discovery">
      {queueIds && (
        <div className="active-collection-banner" data-testid="active-collection-banner">
          <span><strong>{queueTitle || 'Küratör seçkisi'}</strong><small>{queueIds.length} film · bu listeden</small></span>
          <button type="button" onClick={onExitQueue} data-testid="button-exit-collection">Tüm keşif <X size={13} /></button>
        </div>
      )}
      <div className="discovery-filter-toolbar">
        <button
          className={`filter-toggle ${filtersOpen ? 'is-open' : ''}`}
          type="button"
          onClick={() => setFiltersOpen((open) => !open)}
          aria-expanded={filtersOpen}
          aria-controls="discovery-filter-panel"
          data-testid="button-toggle-filters"
        >
          <SlidersHorizontal size={15} />
          <span>Filtreler</span>
          <ChevronRight className="filter-toggle-chevron" size={15} />
        </button>
      </div>
      <div
        id="discovery-filter-panel"
        className={`discovery-filter-panel ${filtersOpen ? 'is-open' : ''}`}
        aria-hidden={!filtersOpen}
        data-testid="panel-discovery-filters"
      >
        <fieldset className="discovery-filter-fieldset">
          <legend>Türler</legend>
          <div className="discovery-genre-pills">
            {discoveryGenres.map((genre) => {
              const selected = draftFilters.genres.includes(genre);
              return (
                <button
                  className={`discovery-genre-pill ${selected ? 'selected' : ''}`}
                  type="button"
                  key={genre}
                  aria-pressed={selected}
                  onClick={() => setDraftFilters((currentFilters) => ({
                    ...currentFilters,
                    genres: selected
                      ? currentFilters.genres.filter((item) => item !== genre)
                      : [...currentFilters.genres, genre],
                  }))}
                  data-testid={`filter-genre-${genre.toLowerCase().replaceAll(' ', '-')}`}
                >
                  {genre}
                </button>
              );
            })}
          </div>
        </fieldset>
        <div className="discovery-filter-year-row">
          <label className="discovery-filter-control">
            <span>En erken yıl</span>
            <select
              value={draftFilters.minYear}
              onChange={(event) => {
                const minYear = Number(event.currentTarget.value);
                setDraftFilters((currentFilters) => ({
                  ...currentFilters,
                  minYear,
                  maxYear: Math.max(minYear, currentFilters.maxYear),
                }));
              }}
              data-testid="filter-min-year"
            >
              {discoveryYearOptions.map((year) => <option value={year} key={year}>{year}</option>)}
            </select>
          </label>
          <label className="discovery-filter-control">
            <span>En geç yıl</span>
            <select
              value={draftFilters.maxYear}
              onChange={(event) => {
                const maxYear = Number(event.currentTarget.value);
                setDraftFilters((currentFilters) => ({
                  ...currentFilters,
                  minYear: Math.min(currentFilters.minYear, maxYear),
                  maxYear,
                }));
              }}
              data-testid="filter-max-year"
            >
              {discoveryYearOptions.map((year) => <option value={year} key={year}>{year}</option>)}
            </select>
          </label>
        </div>
        <label className="discovery-rating-control" htmlFor="discovery-min-rating">
          <span className="discovery-rating-heading">
            <span>Minimum IMDb puanı</span>
            <strong data-testid="filter-rating-value">{draftFilters.minRating.toFixed(1)}+</strong>
          </span>
          <input
            id="discovery-min-rating"
            type="range"
            min="6"
            max="10"
            step="0.5"
            value={draftFilters.minRating}
            onChange={(event) => {
              const minRating = Number(event.currentTarget.value);
              setDraftFilters((currentFilters) => ({
                ...currentFilters,
                minRating,
              }));
            }}
            data-testid="filter-min-rating"
          />
          <span className="discovery-rating-scale"><span>6.0</span><span>10.0</span></span>
        </label>
        <div className="discovery-filter-actions">
          <button className="primary-button apply-discovery-filters" type="button" onClick={applyFilters} data-testid="button-apply-filters">
            Filtreleri Uygula
          </button>
          <button className="reset-discovery-filters" type="button" onClick={resetFilters} data-testid="button-reset-filters">
            Sıfırla
          </button>
        </div>
      </div>

      {matchFeedback !== null && (
        <div className="filter-match-banner" role="status" aria-live="polite" data-testid="status-filter-match-count">
          <Check size={15} />
          <span>Kriterlere uyan {matchFeedback.count} film bulundu</span>
        </div>
      )}

      <div className="discovery-head">
        <div>
          <div className="eyebrow">Bu akşam birlikte</div>
          <h1 className="page-title">Sıradaki film?</h1>
          <p className="subcopy">İkinizin de içinden geçen filmi bulalım.</p>
        </div>
        <div className="session-count" data-testid="queue-count"><strong>{queue.length}</strong> film kaldı</div>
      </div>

      {current ? (
        <>
          <div className="movie-stage">
            <article
              className="movie-card"
              data-testid={`movie-card-${current.id}`}
              onPointerDown={onPointerDown}
              onPointerMove={onPointerMove}
              onPointerUp={onPointerUp}
              onPointerCancel={onPointerUp}
              onClick={() => { if (!dragged.current) onMovieOpen(current); }}
              style={{ transform: `translateX(${gestureX}px) rotate(${gestureX * .035}deg)` }}
              aria-label={`${current.title}, sürükleyerek beğen veya geç`}
            >
              <img src={current.posterUrl} alt={`${current.title} film posteri`} draggable={false} data-testid={`poster-current-${current.id}`} />
              <div className="card-vignette" />
              <span className="poster-badge">BU AKŞAMIN ADAYI</span>
              <span className="poster-rating"><Star size={13} fill="currentColor" /> {current.rating.toFixed(1)}</span>
              <span className={`swipe-stamp like ${gestureX > 20 ? 'visible' : ''}`} style={{ opacity: Math.min(1, Math.max(0, gestureX / 80)) }}>BEĞENDİM</span>
              <span className={`swipe-stamp pass ${gestureX < -20 ? 'visible' : ''}`} style={{ opacity: Math.min(1, Math.max(0, -gestureX / 80)) }}>PAS</span>
              <div className="movie-info">
                <div className="movie-meta"><span>{current.year}</span><span className="meta-dot" /><span><Clock3 size={12} style={{ verticalAlign: '-2px' }} /> {current.runtime} dk</span></div>
                <h2 className="movie-title">{current.title}</h2>
                <div className="genre-row">{current.genres.map(genre => <span className="genre-chip" key={genre}>{genre}</span>)}</div>
                <p className="synopsis">{current.synopsis}</p>
                <div className="provider-line">
                  {current.providers.map(provider => {
                    const providerClass = provider === 'Netflix' ? 'netflix' : provider === 'Prime Video' ? 'prime' : provider === 'MUBI' ? 'mubi' : 'max';
                    const providerInitial = provider === 'Netflix' ? 'N' : provider === 'Prime Video' ? 'P' : provider === 'MUBI' ? 'M' : 'M';
                    return (
                      <span className="provider-badge" key={provider}>
                        <span className={`provider-mark ${providerClass}`}>{providerInitial}</span>
                        <span>{provider}</span>
                      </span>
                    );
                  })}
                </div>
              </div>
            </article>
          </div>
          <div className="action-row">
            <button className="action-btn undo-btn" onClick={undo} disabled={!lastAction} aria-label="Son işlemi geri al" data-testid="button-undo" style={{ opacity: lastAction ? 1 : .45 }}>
              <RotateCcw size={17} />
            </button>
            <button className="action-btn pass-btn" onClick={() => decide('pass')} aria-label="Filmi geç" data-testid="button-pass"><X size={25} strokeWidth={2.7} /></button>
            <button className="action-btn like-btn" onClick={() => decide('like')} aria-label="Filmi beğen" data-testid="button-like"><Heart size={27} fill="currentColor" strokeWidth={2.5} /></button>
          </div>
          <button className="discovery-story-button" type="button" onClick={() => onStory(current)} data-testid={`button-story-discovery-${current.id}`}><Share2 size={14} /> Story'de Paylaş</button>
          <div className="action-caption">Geçmek için sola, beğenmek için sağa kaydır</div>
        </>
      ) : matchedMovies.length === 0 ? (
        <div className="finished-card filter-no-results" data-testid="status-no-filter-results">
          <div className="finished-icon"><Filter size={27} /></div>
          <h2>Film bulunamadı</h2>
          <p>Bu kriterlere uygun film bulunamadı, filtreleri esnetmeyi dene</p>
          <button className="primary-button" onClick={() => setFiltersOpen(true)} data-testid="button-adjust-filters">
            Filtreleri düzenle <ChevronRight size={15} />
          </button>
        </div>
      ) : (
        <div className="finished-card" data-testid="status-queue-finished">
          <div className="finished-icon"><Check size={30} /></div>
          <h2>Hepsi bu kadar!</h2>
          <p>Bu akşam için tüm adayları değerlendirdiniz. Beğendiklerinize kütüphanenizden göz atın veya sırayı baştan başlatın.</p>
          <button className="primary-button" onClick={() => setSaved({ ...saved, passed: [] })} data-testid="button-restart-queue"><RotateCcw size={15} /> Sırayı yeniden başlat</button>
        </div>
      )}
    </main>
  );
}

const collections = [
  { id: 'mind-bending', label: 'ZİHNİNİ AÇ', title: 'Aklı Baştan Alan Psikolojik Gerilimler', description: 'Gerçeklik, hafıza ve güven duygusu yerinden oynuyor.', movieIds: ['inception', 'get-out', 'dark-knight'], count: '3 film' },
  { id: 'weekend-comedies', label: 'HAFTA SONU MODU', title: 'Hafta Sonu Çerezlik Komediler', description: 'Rahat bir akşam, iyi bir hikâye ve biraz kahkaha.', movieIds: ['grand-budapest', 'truman-show', 'groundhog-day'], count: '3 film' },
  { id: 'masterpieces', label: 'YÜKSEK PUANLI', title: 'IMDb 8.5+ Başyapıtlar', description: 'Kolektif hafızada yer etmiş, yeniden izlemeye değer filmler.', movieIds: ['interstellar', 'inception', 'dark-knight', 'whiplash', 'spirited-away', 'lord-of-the-rings'], count: '6 film' },
];

function Curated({ onMovieOpen, onStartQueue }: { onMovieOpen: (movie: Movie) => void; onStartQueue: (ids: string[], title: string) => void }) {
  return (
    <main className="page" data-testid="page-curated">
      <div className="section-head">
        <div>
          <div className="eyebrow">Editörün seçimi</div>
          <h1 className="page-title">Birlikte keşfedin.</h1>
          <p className="subcopy">Modunuza göre küçük film listeleri.</p>
        </div>
      </div>
      <section className="collection-stack" aria-label="Film koleksiyonları">
        {collections.map(collection => {
          const featured = collection.movieIds.map(id => movies.find(movie => movie.id === id)).filter((movie): movie is Movie => Boolean(movie));
          return (
            <article className="collection-card" key={collection.id} data-testid={`collection-${collection.id}`}>
              <div className="collection-art" aria-hidden="true">
                {featured.map(movie => <img key={movie.id} src={movie.posterUrl} alt="" />)}
              </div>
              <div className="collection-overlay" />
              <div className="collection-content">
                <div className="collection-label">{collection.label}</div>
                <h2 className="collection-title">{collection.title}</h2>
                <p className="collection-desc">{collection.description}</p>
                <div className="curated-movie-previews">
                  {featured.map(movie => <button type="button" key={movie.id} className="curated-preview" onClick={() => onMovieOpen(movie)} data-testid={`curated-movie-${movie.id}`}>
                    <img src={movie.posterUrl} alt="" /><span>{movie.title}</span><strong>IMDb {movie.rating.toFixed(1)}</strong>
                  </button>)}
                </div>
                <div className="collection-foot">
                  <span className="mini-posters">{featured.map(movie => <img key={movie.id} src={movie.posterUrl} alt="" />)}</span>
                  <span>{collection.count}</span>
                  <button className="collection-start" type="button" onClick={() => onStartQueue(collection.movieIds, collection.title)} data-testid={`button-start-collection-${collection.id}`}>Bu listeden keşfet <ChevronRight size={14} /></button>
                </div>
              </div>
            </article>
          );
        })}
      </section>
    </main>
  );
}

function Library({ saved, setSaved, onMovieOpen }: { saved: SavedState; setSaved: (value: SavedState) => void; onMovieOpen: (movie: Movie) => void }) {
  const [tab, setTab] = useState<'watchlist' | 'watched'>('watchlist');
  const [genre, setGenre] = useState('Tüm türler');
  const [provider, setProvider] = useState('Tüm platformlar');
  const [rating, setRating] = useState(0);
  const ids = tab === 'watchlist' ? saved.liked.filter(id => !saved.watched.includes(id)) : saved.watched;
  const filteredMovies = movies.filter(movie =>
    ids.includes(movie.id) &&
    (genre === 'Tüm türler' || movie.genres.includes(genre)) &&
    (provider === 'Tüm platformlar' || movie.providers.includes(provider)) &&
    movie.rating >= rating,
  );
  const toggleWatched = (movie: Movie) => {
    const watched = saved.watched.includes(movie.id)
      ? saved.watched.filter(id => id !== movie.id)
      : [...saved.watched, movie.id];
    setSaved({ ...saved, watched, liked: saved.liked.includes(movie.id) ? saved.liked : [...saved.liked, movie.id] });
  };

  return (
    <main className="page" data-testid="page-library">
      <div className="section-head">
        <div>
          <div className="eyebrow">Senin sinema rafın</div>
          <h1 className="page-title">Kütüphanem</h1>
          <p className="subcopy">Birlikte izlemek için ayırdıkların burada.</p>
        </div>
        <span style={{ color: '#f59e0b', fontSize: 12, fontWeight: 800 }} data-testid="library-total">{saved.liked.length} film</span>
      </div>
      <div className="library-tabs" role="tablist" aria-label="Kütüphane kategorisi">
        <button className={`library-tab ${tab === 'watchlist' ? 'active' : ''}`} onClick={() => setTab('watchlist')} role="tab" aria-selected={tab === 'watchlist'} data-testid="tab-watchlist">
          İzlenecekler <span className="tab-count">{saved.liked.filter(id => !saved.watched.includes(id)).length}</span>
        </button>
        <button className={`library-tab ${tab === 'watched' ? 'active' : ''}`} onClick={() => setTab('watched')} role="tab" aria-selected={tab === 'watched'} data-testid="tab-watched">
          İzlediklerim <span className="tab-count">{saved.watched.length}</span>
        </button>
      </div>
      <section className="filter-panel" aria-label="Film filtreleri">
        <div className="filter-title"><Filter size={14} /> Filtrele</div>
        <div className="filter-row">
          <select className="filter-select" value={genre} onChange={event => setGenre(event.target.value)} aria-label="Türe göre filtrele" data-testid="filter-genre">
            <option>Tüm türler</option>
            {Array.from(new Set(movies.flatMap(movie => movie.genres))).sort().map(item => <option key={item}>{item}</option>)}
          </select>
          <select className="filter-select" value={provider} onChange={event => setProvider(event.target.value)} aria-label="Platforma göre filtrele" data-testid="filter-provider">
            <option>Tüm platformlar</option>
            {Array.from(new Set(movies.flatMap(movie => movie.providers))).sort().map(item => <option key={item}>{item}</option>)}
          </select>
        </div>
        <div className="rating-filters" role="group" aria-label="Minimum IMDb puanı">
          <span className="rating-label">IMDb</span>
          {[0, 7, 7.5, 8].map(value => (
            <button key={value} className={`rating-chip ${rating === value ? 'active' : ''}`} onClick={() => setRating(value)} data-testid={`filter-rating-${value === 0 ? 'all' : String(value).replace('.', '-')}`}>
              {value === 0 ? 'Tümü' : `${value}+`}
            </button>
          ))}
        </div>
      </section>
      <section className="movie-list" aria-live="polite" data-testid="library-movie-list">
        {filteredMovies.length ? filteredMovies.map(movie => {
          const isWatched = saved.watched.includes(movie.id);
          return (
            <article className="movie-row" key={movie.id} data-testid={`library-row-${movie.id}`}>
              <button className="library-movie-open" type="button" onClick={() => onMovieOpen(movie)} aria-label={`${movie.title} detaylarını aç`} data-testid={`button-library-open-${movie.id}`}><img className="row-poster" src={movie.posterUrl} alt={`${movie.title} posteri`} /></button>
              <div className="row-info">
                <button className="row-title-button" type="button" onClick={() => onMovieOpen(movie)} data-testid={`button-library-title-${movie.id}`}><h2 className="row-title">{movie.title}</h2></button>
                <div className="row-meta">{movie.year} <span style={{ color: '#475569' }}>·</span> {movie.runtime} dk</div>
                <div className="row-tags">{movie.genres.slice(0, 2).map(item => <span className="row-tag" key={item}>{item}</span>)}</div>
                <span className="row-rating"><Star size={11} fill="currentColor" /> IMDb {movie.rating.toFixed(1)}</span>
              </div>
              <button className={`watched-toggle ${isWatched ? 'is-watched' : ''}`} onClick={() => toggleWatched(movie)} aria-label={isWatched ? `${movie.title} izlenmedi olarak işaretle` : `${movie.title} izledim olarak işaretle`} data-testid={`toggle-watched-${movie.id}`}>
                {isWatched ? <Check size={16} /> : <ThumbsUp size={16} />}
                <span>{isWatched ? 'İzlendi' : 'İzledim'}</span>
              </button>
            </article>
          );
        }) : (
          <div className="empty-state" data-testid="empty-library">
            <Bookmark size={25} />
            <h3>{tab === 'watchlist' ? 'Rafın henüz boş' : 'İzlenen film yok'}</h3>
            <p>{tab === 'watchlist' ? 'Keşfet sayfasında beğendiğin filmler burada birikecek.' : 'İzlediğin filmleri burada işaretleyip arşivleyebilirsin.'}</p>
          </div>
        )}
      </section>
    </main>
  );
}

type MatchUser = {
  id: string;
  username: string;
  commonMovieCount: number;
  commonMovies: string[];
};

const matchUsers: MatchUser[] = [
  {
    id: 'cinemyth',
    username: 'cinemyth',
    commonMovieCount: 18,
    commonMovies: ['Interstellar', 'Inception', 'The Grand Budapest Hotel', 'Arrival', 'Her'],
  },
  {
    id: 'filmkurdu',
    username: 'filmkurdu',
    commonMovieCount: 12,
    commonMovies: ['Whiplash', 'The Dark Knight', 'Dune', 'Parasite'],
  },
  {
    id: 'sinemasever',
    username: 'sinemasever',
    commonMovieCount: 9,
    commonMovies: ['Spirited Away', 'The Lord of the Rings', 'Get Out'],
  },
];

function readFollowedMatches(username: string | null): string[] {
  if (!username) return [];
  try {
    const parsed: unknown = JSON.parse(localStorage.getItem(`cineswipe-follows:${username}`) || '[]');
    return Array.isArray(parsed) ? parsed.filter((id): id is string => typeof id === 'string') : [];
  } catch {
    return [];
  }
}

function Matches({ username, onOpenProfile, onStory }: { username: string | null; onOpenProfile: () => void; onStory: (movie: Movie, matchName?: string) => void }) {
  const [followed, setFollowed] = useState<string[]>(() => readFollowedMatches(username));
  const [expanded, setExpanded] = useState<string[]>([]);
  const [premiumUser, setPremiumUser] = useState<string | null>(null);

  useEffect(() => {
    if (!username) return;
    try {
      localStorage.setItem(`cineswipe-follows:${username}`, JSON.stringify(followed));
    } catch {
      // Keep follow state usable for this session if local storage is unavailable.
    }
  }, [followed, username]);

  const toggleFollow = (id: string) => {
    setFollowed(current => current.includes(id) ? current.filter(item => item !== id) : [...current, id]);
  };

  const toggleMovies = (id: string) => {
    setExpanded(current => current.includes(id) ? current.filter(item => item !== id) : [...current, id]);
  };

  return (
    <main className="page matches-page" data-testid="page-matches">
      <div className="matches-heading">
        <div className="matches-heading-copy">
          <div className="eyebrow">Aynı filmler, yeni sohbetler</div>
          <h1 className="page-title">Eşleşmeler</h1>
          <p className="subcopy">Film zevkinin kesiştiği izleyiciler.</p>
        </div>
        <div className="matches-heading-mark" aria-hidden="true"><Users size={21} /></div>
      </div>

      {!username ? (
        <section className="matches-guest-card" data-testid="matches-sign-in-prompt">
          <div className="matches-guest-icon"><UserRound size={22} /></div>
          <div className="matches-guest-kicker">Sana özel keşif</div>
          <h2>Film arkadaşlarını bul.</h2>
          <p>Giriş yapınca ortak favorilerini görebilir, izleyicileri takip edebilirsin.</p>
          <button className="primary-button matches-sign-in" type="button" onClick={onOpenProfile} data-testid="button-matches-sign-in">
            Giriş yap veya kaydol <ChevronRight size={16} />
          </button>
        </section>
      ) : (
        <>
          <div className="matches-summary" data-testid="matches-summary">
            <span className="matches-summary-dot" />
            <span><strong>3 izleyici</strong> film zevkini paylaşıyor</span>
            <span className="matches-summary-user">@{username}</span>
          </div>
          <aside className="premium-teaser" data-testid="banner-premium">
            <span className="premium-teaser-icon"><Crown size={17} /></span>
            <span className="premium-teaser-copy">
              <strong>Bir üst perde</strong>
              <span>Mesajlaşma ve Süper Eşleşme Premium ile açılır.</span>
            </span>
            <span className="premium-teaser-tag">PREMIUM</span>
          </aside>
          <section className="match-list" aria-label="Film eşleşmeleri">
            {matchUsers.map((user, index) => {
              const isFollowing = followed.includes(user.id);
              const isExpanded = expanded.includes(user.id);
              return (
                <article className="match-card" key={user.id} data-testid={`match-card-${user.id}`}>
                  <div className="match-card-top">
                    <div className={`match-avatar match-avatar-${index + 1}`} aria-hidden="true">{user.username.slice(0, 1).toUpperCase()}</div>
                    <div className="match-user-copy">
                      <h2 data-testid={`text-match-username-${user.id}`}>@{user.username}</h2>
                      <span><strong>{user.commonMovieCount} ortak filmde</strong> eşleştiniz</span>
                    </div>
                    <span className="match-score" aria-label={`${user.commonMovieCount} ortak film`}>
                      <Heart size={12} fill="currentColor" /> {user.commonMovieCount}
                    </span>
                  </div>
                  <div className="match-card-actions">
                    <button
                      className={`match-follow-button ${isFollowing ? 'is-following' : ''}`}
                      type="button"
                      onClick={() => toggleFollow(user.id)}
                      aria-pressed={isFollowing}
                      data-testid={`button-follow-${user.id}`}
                    >
                      {isFollowing ? <UserCheck size={15} /> : <UserPlus size={15} />}
                      {isFollowing ? 'Takiptesin' : 'Takip Et'}
                    </button>
                    <button
                      className="match-message-button"
                      type="button"
                      onClick={() => setPremiumUser(user.username)}
                      data-testid={`button-message-${user.id}`}
                    >
                      <MessageCircle size={15} /> Mesaj Gönder
                    </button>
                  </div>
                  <button className="match-story-button" type="button" onClick={() => {
                    const movie = movies.find(item => user.commonMovies.some(title => title.toLowerCase() === item.title.toLowerCase())) || movies[0];
                    onStory(movie, user.username);
                  }} data-testid={`button-match-story-${user.id}`}><Share2 size={14} /> Eşleşmenle Story'de Paylaş</button>
                  <button
                    className="match-movies-toggle"
                    type="button"
                    onClick={() => toggleMovies(user.id)}
                    aria-expanded={isExpanded}
                    aria-controls={`common-movies-${user.id}`}
                    data-testid={`button-common-movies-${user.id}`}
                  >
                    <span>{isExpanded ? 'Ortak filmleri gizle' : 'Ortak filmleri gör'}</span>
                    <span className="match-movie-count">{user.commonMovies.length} başlık</span>
                    <ChevronDown className={isExpanded ? 'is-rotated' : ''} size={16} />
                  </button>
                  {isExpanded && (
                    <div className="common-movies-list" id={`common-movies-${user.id}`} data-testid={`list-common-movies-${user.id}`}>
                      {user.commonMovies.map((title, movieIndex) => (
                        <div className="common-movie-row" key={title} data-testid={`common-movie-${user.id}-${movieIndex}`}>
                          <span className="common-movie-index">{String(movieIndex + 1).padStart(2, '0')}</span>
                          <span>{title}</span>
                          <Check size={14} />
                        </div>
                      ))}
                    </div>
                  )}
                </article>
              );
            })}
          </section>
          <p className="matches-footnote">Eşleşmeler, beğendiğin ve izlediğin filmlere göre hazırlanır.</p>
        </>
      )}

      {premiumUser && (
        <div className="premium-backdrop" role="presentation" onMouseDown={(event) => {
          if (event.currentTarget === event.target) setPremiumUser(null);
        }}>
          <section className="premium-dialog" role="dialog" aria-modal="true" aria-labelledby="premium-title" data-testid="dialog-premium-message">
            <button className="premium-close" type="button" onClick={() => setPremiumUser(null)} aria-label="Pencereyi kapat" data-testid="button-close-premium"><X size={17} /></button>
            <div className="premium-lock"><LockKeyhole size={21} /></div>
            <div className="eyebrow">CineSwipe Premium</div>
            <h2 id="premium-title">Sohbetin kapısını aç.</h2>
            <p><strong>@{premiumUser}</strong> kullanıcısına mesaj göndermek Premium üyelikle kullanılabilir. Şimdilik takip ederek yeni ortak filmleri keşfedebilirsin.</p>
            <button className="primary-button premium-dismiss" type="button" onClick={() => setPremiumUser(null)} data-testid="button-dismiss-premium">Anladım</button>
          </section>
        </div>
      )}
    </main>
  );
}

function NotFound() {
  return <main className="page"><div className="empty-state"><Film size={26} /><h3>Bu salon bulunamadı</h3><Link href="/" className="primary-button">Keşfe dön</Link></div></main>;
}

function App() {
  const [username, setUsername] = useState<string | null>(() => readActiveUsername());
  const [saved, setSaved] = useState<SavedState>(() => readSavedForUser(readActiveUsername()));
  const [profileOpen, setProfileOpen] = useState(false);
  const [, setLocation] = useLocation();
  const [queueIds, setQueueIds] = useState<string[] | null>(null);
  const [queueTitle, setQueueTitle] = useState<string | null>(null);
  const [selectedMovie, setSelectedMovie] = useState<Movie | null>(null);
  const [story, setStory] = useState<{ movie: Movie; matchName?: string } | null>(null);

  useEffect(() => {
    saveForUser(username, saved);
  }, [saved, username]);

  const activateProfile = (nextUsername: string) => {
    setActiveUsername(nextUsername);
    setUsername(nextUsername);
    setSaved(readSavedForUser(nextUsername));
    setProfileOpen(false);
  };

  const logout = () => {
    setActiveUsername(null);
    setUsername(null);
    setSaved(readSavedForUser(null));
    setProfileOpen(false);
    setLocation('/');
  };
  const addToWatchlist = (movie: Movie) => setSaved(current => ({ ...current, liked: current.liked.includes(movie.id) ? current.liked : [...current.liked, movie.id] }));
  const markWatched = (movie: Movie) => setSaved(current => ({
    ...current,
    liked: current.liked.includes(movie.id) ? current.liked : [...current.liked, movie.id],
    watched: current.watched.includes(movie.id) ? current.watched : [...current.watched, movie.id],
  }));

  return (
    <div className="app-shell">
      <div className="mobile-frame">
        <Header username={username} onOpenProfile={() => username ? setLocation('/profile') : setProfileOpen(true)} />
        <Switch>
          <Route path="/"><Discovery saved={saved} setSaved={setSaved} queueIds={queueIds} queueTitle={queueTitle} onExitQueue={() => { setQueueIds(null); setQueueTitle(null); }} onMovieOpen={setSelectedMovie} onStory={(movie) => setStory({ movie })} /></Route>
          <Route path="/curated"><Curated onMovieOpen={setSelectedMovie} onStartQueue={(ids, title) => { setQueueIds(ids); setQueueTitle(title); setLocation('/'); }} /></Route>
          <Route path="/library"><Library saved={saved} setSaved={setSaved} onMovieOpen={setSelectedMovie} /></Route>
          <Route path="/matches"><Matches key={username ?? 'guest'} username={username} onOpenProfile={() => setProfileOpen(true)} onStory={(movie, matchName) => setStory({ movie, matchName })} /></Route>
          <Route path="/profile">{username ? <ProfilePage key={username} username={username} movies={movies} onLogout={logout} /> : <main className="page profile-guest"><div className="matches-guest-card"><div className="matches-guest-icon"><UserRound size={22} /></div><div className="matches-guest-kicker">Kişisel sinema günlüğü</div><h2>Profilin için giriş yap.</h2><p>Profil bilgilerin ve film rafın kullanıcı adına bağlı olarak bu cihazda saklanır.</p><button className="primary-button" type="button" onClick={() => setProfileOpen(true)} data-testid="button-profile-guest-login">Giriş yap veya kaydol</button></div></main>}</Route>
          <Route><NotFound /></Route>
        </Switch>
        <BottomNav />
      </div>
      {profileOpen && (
        <ProfileModal
          username={username}
          onClose={() => setProfileOpen(false)}
          onActivate={activateProfile}
          onLogout={logout}
        />
      )}
      {selectedMovie && <MovieDetailSheet movie={selectedMovie} movies={movies} onClose={() => setSelectedMovie(null)} onAdd={addToWatchlist} onWatched={markWatched} onShare={movie => setStory({ movie })} />}
      {story && <StoryOverlay movie={story.movie} matchName={story.matchName} username={username || 'misafir'} onClose={() => setStory(null)} />}
    </div>
  );
}

export default App;
