import { useState } from 'react';
import { Check, Share2, X } from 'lucide-react';
import type { Movie } from './MovieDetailSheet';

type Props = { movie: Movie; matchName?: string; username: string; onClose: () => void };

export default function StoryOverlay({ movie, matchName, username, onClose }: Props) {
  const [shared, setShared] = useState(false);
  const currentInitial = username.replace(/^@/, '').slice(0, 2).toUpperCase() || 'CS';
  const matchInitial = matchName?.slice(0, 2).toUpperCase() || 'CS';
  return (
    <div className="story-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }} data-testid="story-overlay">
      <section className="story-dialog" role="dialog" aria-modal="true" aria-label="Film hikâyesi paylaşımı">
        <button className="story-close" type="button" onClick={onClose} aria-label="Hikâyeyi kapat" data-testid="button-close-story"><X size={18} /></button>
        <div className="story-art" style={{ backgroundImage: `url("${movie.posterUrl}")` }} />
        <div className="story-vignette" />
        <div className="story-content">
          <header className="story-heading">Bu Akşam Ne İzliyoruz? 🎬</header>
          <div className="story-participants" data-testid="story-participants">
            <span className="story-avatar" title={`@${username}`}>{currentInitial}</span>
            <span className="story-avatar">{matchInitial}</span>
            <span>{matchName ? `@${username} + @${matchName}` : `@${username} · Birlikte izlemeye hazır`}</span>
          </div>
          <div className="story-film">
            <span className="story-kicker">BU AKŞAMIN SEÇİMİ</span>
            <h2>{movie.title}</h2>
            <div className="story-rating">IMDb <strong>{movie.rating.toFixed(1)}</strong><span>·</span><span>{movie.year}</span></div>
            <div className="story-tags">{movie.genres.slice(0, 3).map(tag => <span key={tag}>{tag}</span>)}</div>
            <div className="story-match">{matchName ? 'Film zevkiniz kesişiyor' : 'Sıradaki film adayınız'}</div>
          </div>
          <footer>CineSwipe | Powered by @reelsformovie</footer>
        </div>
        <button className="story-share" type="button" onClick={() => setShared(true)} data-testid="button-story-share">
          {shared ? <Check size={17} /> : <Share2 size={17} />}{shared ? 'Paylaşım hazır' : 'Görseli İndir / Paylaş'}
        </button>
        {shared && <div className="story-feedback" role="status" data-testid="story-share-success">Hikâye görseli hazır. Cihazında paylaşabilirsin.</div>}
      </section>
    </div>
  );
}
