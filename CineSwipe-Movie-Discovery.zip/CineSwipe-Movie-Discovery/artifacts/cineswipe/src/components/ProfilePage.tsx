import { useState, type FormEvent } from 'react';
import { Film, MapPin, Pencil, Quote, UserRound, X, LogOut } from 'lucide-react';
import type { Movie } from './MovieDetailSheet';

export type ViewerProfile = { name: string; age: string; city: string; gender: string; bio: string; quote: string; favorites: string[] };
const defaultProfile = (username: string): ViewerProfile => ({
  name: username.replaceAll('_', ' ').replace(/\b\w/g, letter => letter.toUpperCase()),
  age: '28', city: 'İstanbul', gender: 'Belirtmek istemiyor',
  bio: 'Jenerik aktıktan sonra da hikâyenin içinde kalırım. Yeni dünyalar keşfetmek için buradayım.',
  quote: '“Bazen en iyi yolculuk, eve dönüş yoludur.”',
  favorites: ['Interstellar', 'Inception', 'The Grand Budapest Hotel'],
});
const profileKey = (username: string) => `cineswipe-profile:${username}`;
export function readViewerProfile(username: string): ViewerProfile {
  try {
    const saved = JSON.parse(localStorage.getItem(profileKey(username)) || 'null') as Partial<ViewerProfile> | null;
    const fallback = defaultProfile(username);
    return { ...fallback, ...saved, favorites: Array.isArray(saved?.favorites) ? saved.favorites.slice(0, 3) : fallback.favorites };
  } catch { return defaultProfile(username); }
}
export function saveViewerProfile(username: string, profile: ViewerProfile) {
  try { localStorage.setItem(profileKey(username), JSON.stringify(profile)); } catch { /* session remains editable */ }
}

type Props = { username: string; movies: Movie[]; onLogout: () => void };
export default function ProfilePage({ username, movies, onLogout }: Props) {
  const [profile, setProfile] = useState(() => readViewerProfile(username));
  const [editing, setEditing] = useState(false);
  const genres = ['Bilim Kurgu', 'Dram', 'Gerilim'];
  const save = (next: ViewerProfile) => { setProfile(next); saveViewerProfile(username, next); setEditing(false); };
  return (
    <main className="page profile-page" data-testid="page-profile">
      <div className="profile-page-head"><div><div className="eyebrow">İzleme günlüğün</div><h1 className="page-title">Profilim</h1></div><button className="profile-edit-button" type="button" onClick={() => setEditing(true)} data-testid="button-edit-profile"><Pencil size={15} /> Profili Düzenle</button></div>
      <section className="profile-hero-card">
        <div className="profile-avatar-large" data-testid="profile-avatar">{profile.name.split(' ').map(part => part[0]).slice(0, 2).join('').toUpperCase() || username.slice(0, 1).toUpperCase()}</div>
        <div className="profile-identity"><h2 data-testid="profile-name">{profile.name}</h2><span data-testid="profile-username">@{username}</span></div>
        <div className="profile-badges"><span><Film size={13} /> Sinemasever</span><span>50+ Film İzledi</span></div>
        <p className="profile-bio" data-testid="profile-bio">{profile.bio}</p>
        <div className="profile-facts"><span><MapPin size={14} /> {profile.city}</span><span>{profile.age} yaş</span><span>{profile.gender}</span></div>
        <blockquote><Quote size={15} /> {profile.quote}</blockquote>
      </section>
      <section className="profile-section">
        <div className="profile-section-head"><div><span className="eyebrow">Tekrar tekrar</span><h2>Favori filmlerim</h2></div><span className="profile-count">03</span></div>
        <div className="favorite-film-list">{profile.favorites.map((title, index) => {
          const favorite = movies.find(movie => movie.title.toLowerCase() === title.toLowerCase());
          return (
            <div className="favorite-film" key={`${title}-${index}`} data-testid={`favorite-film-${index + 1}`}>
              <span className="favorite-number">0{index + 1}</span>
              <span className="favorite-poster-mark">
                {favorite ? <img src={favorite.posterUrl} alt={`${favorite.title} posteri`} data-testid={`favorite-poster-${index + 1}`} /> : title.slice(0, 1)}
              </span>
              <strong>{title}</strong>
            </div>
          );
        })}</div>
      </section>
      <section className="profile-section genre-section">
        <div className="profile-section-head"><div><span className="eyebrow">Film zevkin</span><h2>Favori türler</h2></div></div>
        <div className="profile-genre-list">{genres.map(genre => <span key={genre}>{genre}</span>)}</div>
      </section>
      <button className="profile-page-logout" type="button" onClick={onLogout} data-testid="button-profile-logout"><LogOut size={15} /> Oturumu kapat</button>
      {editing && <EditProfile initial={profile} onClose={() => setEditing(false)} onSave={save} />}
    </main>
  );
}

function EditProfile({ initial, onClose, onSave }: { initial: ViewerProfile; onClose: () => void; onSave: (profile: ViewerProfile) => void }) {
  const [draft, setDraft] = useState(initial);
  const update = (key: keyof ViewerProfile, value: string) => setDraft(current => ({ ...current, [key]: value }));
  const submit = (event: FormEvent<HTMLFormElement>) => { event.preventDefault(); onSave({ ...draft, favorites: draft.favorites.map(item => item.trim()).filter(Boolean).slice(0, 3) }); };
  return (
    <div className="profile-edit-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }} data-testid="profile-edit-backdrop">
      <section className="profile-edit-modal" role="dialog" aria-modal="true" aria-labelledby="profile-edit-title">
        <header><div><span className="eyebrow">Kendini anlat</span><h2 id="profile-edit-title">Profili düzenle</h2></div><button type="button" onClick={onClose} aria-label="Düzenlemeyi kapat" data-testid="button-close-edit-profile"><X size={18} /></button></header>
        <form onSubmit={submit}>
          <label>Ad<input value={draft.name} onChange={event => update('name', event.currentTarget.value)} data-testid="input-profile-name" /></label>
          <div className="profile-form-grid"><label>Yaş<input inputMode="numeric" value={draft.age} onChange={event => update('age', event.currentTarget.value)} data-testid="input-profile-age" /></label><label>Şehir<input value={draft.city} onChange={event => update('city', event.currentTarget.value)} data-testid="input-profile-city" /></label></div>
          <label>Cinsiyet<input value={draft.gender} onChange={event => update('gender', event.currentTarget.value)} data-testid="input-profile-gender" /></label>
          <label>Kısa biyografi<textarea value={draft.bio} onChange={event => update('bio', event.currentTarget.value)} rows={3} data-testid="input-profile-bio" /></label>
          <label>Favori alıntı<input value={draft.quote} onChange={event => update('quote', event.currentTarget.value)} data-testid="input-profile-quote" /></label>
          <fieldset><legend>İlk üç favori film</legend>{draft.favorites.slice(0, 3).map((film, index) => <input key={index} aria-label={`Favori film ${index + 1}`} value={film} onChange={event => { const value = event.currentTarget.value; setDraft(current => ({ ...current, favorites: current.favorites.map((favorite, itemIndex) => itemIndex === index ? value : favorite) })); }} data-testid={`input-favorite-film-${index + 1}`} />)}</fieldset>
          <button className="primary-button profile-save-button" type="submit" data-testid="button-save-profile"><UserRound size={15} /> Değişiklikleri Kaydet</button>
        </form>
      </section>
    </div>
  );
}
