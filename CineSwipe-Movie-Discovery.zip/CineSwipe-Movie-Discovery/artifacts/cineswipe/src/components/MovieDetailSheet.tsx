import { useEffect, useState } from 'react';
import { ArrowLeft, BookmarkPlus, Check, Clock3, ExternalLink, Play, Share2, Star, X } from 'lucide-react';

export type Movie = {
  id: string;
  title: string;
  year: number;
  rating: number;
  runtime: number;
  genres: string[];
  providers: string[];
  posterUrl: string;
  backdropUrl?: string;
  synopsis: string;
  originalTitle?: string;
  country?: string;
  director?: string;
  cast?: string[];
  trailerUrl?: string;
};

type Props = {
  movie: Movie;
  movies: Movie[];
  onClose: () => void;
  onAdd: (movie: Movie) => void;
  onWatched: (movie: Movie) => void;
  onShare: (movie: Movie) => void;
};

export default function MovieDetailSheet({ movie, movies, onClose, onAdd, onWatched, onShare }: Props) {
  const [person, setPerson] = useState<string | null>(null);
  const [activeMovie, setActiveMovie] = useState(movie);
  useEffect(() => {
    const key = (event: KeyboardEvent) => { if (event.key === 'Escape') onClose(); };
    window.addEventListener('keydown', key);
    return () => window.removeEventListener('keydown', key);
  }, [onClose]);

  const openTrailer = () => {
    const url = activeMovie.trailerUrl || `https://www.youtube.com/results?search_query=${encodeURIComponent(`${activeMovie.title} official trailer`)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  };
  const otherMovies = person
    ? movies.filter(item => item.id !== activeMovie.id && (item.director === person || item.cast?.includes(person)))
    : [];

  return (
    <div className="movie-sheet-backdrop" onMouseDown={event => { if (event.target === event.currentTarget) onClose(); }} data-testid="movie-detail-backdrop">
      <section className="movie-detail-sheet" role="dialog" aria-modal="true" aria-label={`${activeMovie.title} film detayları`} data-testid="movie-detail-sheet">
        <button className="detail-close" type="button" onClick={onClose} aria-label="Film detayını kapat" data-testid="button-close-movie-detail"><X size={19} /></button>
        {person ? (
          <div className="filmography-view">
            <button className="detail-back" type="button" onClick={() => setPerson(null)} data-testid="button-filmography-back"><ArrowLeft size={16} /> Filme dön</button>
            <div className="eyebrow">Filmografi</div>
            <h2>{person}</h2>
            <p className="subcopy">Katalogdaki diğer filmleri</p>
            <div className="filmography-list">
              {otherMovies.length ? otherMovies.map(item => (
                <button className="filmography-item" type="button" key={item.id} onClick={() => { setActiveMovie(item); setPerson(null); }} data-testid={`filmography-movie-${item.id}`}>
                  <img src={item.posterUrl} alt="" /><span><strong>{item.title}</strong><small>{item.year} · IMDb {item.rating.toFixed(1)}</small></span><ExternalLink size={15} />
                </button>
              )) : <div className="empty-state">Bu yerel katalogda başka film bulunmuyor.</div>}
            </div>
          </div>
        ) : (
          <>
            <div className="detail-hero">
              <img src={activeMovie.backdropUrl || activeMovie.posterUrl} alt={`${activeMovie.title} arka planı`} />
              <div className="detail-hero-shade" />
              <div className="detail-hero-copy">
                <span className="eyebrow">Film detayları</span>
                <h2 data-testid={`detail-title-${activeMovie.id}`}>{activeMovie.title}</h2>
                <p><span className="detail-original-label">Orijinal adı:</span> {activeMovie.originalTitle || activeMovie.title}</p>
              </div>
            </div>
            <div className="detail-content">
              <div className="detail-facts">
                <span>{activeMovie.year}</span><span><Clock3 size={13} /> {activeMovie.runtime} dk</span><strong><Star size={13} fill="currentColor" /> IMDb {activeMovie.rating.toFixed(1)}</strong><span>{activeMovie.country || 'ABD'}</span>
              </div>
              <div className="genre-row">{activeMovie.genres.map(genre => <span className="genre-chip" key={genre}>{genre}</span>)}</div>
              <p className="detail-synopsis">{activeMovie.synopsis}</p>
              <div className="detail-section">
                <span className="detail-label">Yönetmen</span>
                <button type="button" className="person-link" onClick={() => setPerson(activeMovie.director || 'Christopher Nolan')} data-testid="button-director">{activeMovie.director || 'Christopher Nolan'}</button>
              </div>
              <div className="detail-section">
                <span className="detail-label">Oyuncular</span>
                <div className="person-list">{(activeMovie.cast || []).map(name => <button key={name} type="button" className="person-link" onClick={() => setPerson(name)} data-testid={`button-cast-${name.toLowerCase().replaceAll(' ', '-')}`}>{name}</button>)}</div>
              </div>
              <div className="detail-section">
                <span className="detail-label">Türkiye'de izlenebilir</span>
                <div className="provider-line">{activeMovie.providers.map(provider => <span className="provider-badge" key={provider}>{provider}</span>)}</div>
              </div>
              <div className="detail-actions">
                <button type="button" className="primary-button" onClick={() => onAdd(activeMovie)} data-testid="button-detail-add"><BookmarkPlus size={15} /> İzleme Listeme Ekle</button>
                <button type="button" className="detail-secondary" onClick={() => onWatched(activeMovie)} data-testid="button-detail-watched"><Check size={15} /> İzledim</button>
                <button type="button" className="detail-secondary" onClick={() => onShare(activeMovie)} data-testid="button-detail-story"><Share2 size={15} /> Story'de Paylaş</button>
                <button type="button" className="detail-secondary trailer-action" onClick={openTrailer} data-testid="button-detail-trailer"><Play size={15} /> Fragman İzle</button>
              </div>
            </div>
          </>
        )}
      </section>
    </div>
  );
}
