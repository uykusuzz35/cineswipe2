import { useEffect, useState, type FormEvent } from 'react';
import { LogOut, UserRound, X } from 'lucide-react';
import { normalizeUsername } from '@/lib/local-profile';

type ProfileModalProps = {
  username: string | null;
  onClose: () => void;
  onActivate: (username: string) => void;
  onLogout: () => void;
};

export default function ProfileModal({
  username,
  onClose,
  onActivate,
  onLogout,
}: ProfileModalProps) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [usernameInput, setUsernameInput] = useState(username ? `@${username}` : '');
  const [error, setError] = useState('');

  useEffect(() => {
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [onClose]);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const normalized = normalizeUsername(usernameInput);
    if (!normalized) {
      setError('Kullanıcı adı 3–20 karakter olmalı; harf, sayı veya alt çizgi kullan.');
      return;
    }
    setError('');
    onActivate(normalized);
  };

  return (
    <div
      className="profile-modal-backdrop"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
      data-testid="profile-modal-backdrop"
    >
      <section
        className="profile-modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="profile-modal-title"
        data-testid="profile-modal"
      >
        <div className="profile-modal-top">
          <span className="profile-modal-icon"><UserRound size={20} /></span>
          <button
            type="button"
            className="profile-modal-close"
            onClick={onClose}
            aria-label="Profili kapat"
            data-testid="button-close-profile"
          >
            <X size={18} />
          </button>
        </div>
        <div className="profile-modal-kicker">CINESWIPE PROFİLİ</div>
        <h2 id="profile-modal-title">{mode === 'register' ? 'Yeni bir profil oluştur' : 'CineSwipe’e giriş yap'}</h2>
        <p className="profile-modal-copy">
          Film seçimlerini kullanıcı adına bağlı tut. Bu demo profili yalnızca bu cihazda saklanır.
        </p>

        <div className="profile-mode-tabs" role="tablist" aria-label="Profil işlemi">
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'login'}
            className={mode === 'login' ? 'active' : ''}
            onClick={() => { setMode('login'); setError(''); }}
            data-testid="tab-profile-login"
          >
            Giriş Yap
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={mode === 'register'}
            className={mode === 'register' ? 'active' : ''}
            onClick={() => { setMode('register'); setError(''); }}
            data-testid="tab-profile-register"
          >
            Kaydol
          </button>
        </div>

        <form className="profile-form" onSubmit={handleSubmit}>
          <label htmlFor="profile-username">Kullanıcı adı</label>
          <input
            id="profile-username"
            type="text"
            value={usernameInput}
            onChange={(event) => { setUsernameInput(event.currentTarget.value); setError(''); }}
            placeholder="@kullaniciadi"
            autoComplete="username"
            autoCapitalize="none"
            autoCorrect="off"
            maxLength={22}
            autoFocus
            aria-invalid={error.length > 0}
            aria-describedby={error ? 'profile-username-error' : undefined}
            data-testid="input-profile-username"
          />
          {error && <p id="profile-username-error" className="profile-form-error" role="alert">{error}</p>}
          <button className="primary-button profile-submit" type="submit" data-testid="button-submit-profile">
            {mode === 'register' ? 'Kaydol' : 'Giriş Yap'}
          </button>
        </form>

        <p className="profile-local-note">
          MVP demo oturumu: parola gerekmez ve gerçek bir hesap oluşturulmaz.
        </p>

        {username && (
          <button className="profile-logout" type="button" onClick={onLogout} data-testid="button-logout">
            <LogOut size={15} /> Oturumu kapat
          </button>
        )}
      </section>
    </div>
  );
}
